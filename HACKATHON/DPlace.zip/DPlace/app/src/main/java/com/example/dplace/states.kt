package com.example.dplace

var ax : List<DataResponse> = listOf()