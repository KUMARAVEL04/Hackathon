//package com.example.dplace
//
//import android.text.TextUtils
//import io.socket.client.IO
//import io.socket.client.Socket
//import java.net.URISyntaxException
//
//
//object SocketHandler {
//
//    lateinit var mSocket: Socket
//
//    @Synchronized
//    fun setSocket() {
//        try {
//            mSocket = IO.socket("http://10.0.2.2:3000")
//        } catch (e: URISyntaxException) {
//
//        }
//    }
//    private fun attemptSend() {
//        val message: String = mInputMessageView.getText().toString().trim()
//        if (TextUtils.isEmpty(message)) {
//            return
//        }
//
//        mInputMessageView.setText("")
//        mSocket.emit("new message", message)
//    }
//
//    @Synchronized
//    fun getSocket(): Socket {
//        return mSocket
//    }
//
//    @Synchronized
//    fun establishConnection() {
//        mSocket.connect()
//    }
//
//    @Synchronized
//    fun closeConnection() {
//        mSocket.disconnect()
//    }
//}
